#!/usr/bin/env bash
# Plain-English summary of what the bot has done.
cd "$(dirname "$0")" || exit 1
PY="./.venv/bin/python"; [ -x "$PY" ] || PY="python3"

RUNNING="no"
if command -v tmux >/dev/null 2>&1 && tmux has-session -t autoreply 2>/dev/null; then
  RUNNING="yes (in the background)"
else
  if pgrep -f "bot.py" >/dev/null 2>&1; then RUNNING="yes (in this or another window)"; fi
fi

echo "=============================================================="
echo "   BOT STATUS"
echo "=============================================================="
echo "  Running right now ......... $RUNNING"
echo "  Auto-reply switched on .... $(grep -E '^FIRST_REPLY_ENABLED=' .env 2>/dev/null | cut -d= -f2 || echo unknown)"
echo "  Welcome on joining ........ $(grep -E '^CONTACT_SIGNUP_ENABLED=' .env 2>/dev/null | cut -d= -f2 || echo unknown)"
echo "  Greet group joins ......... $(grep -E '^GROUP_JOIN_ENABLED=' .env 2>/dev/null | cut -d= -f2 || echo unknown)"
echo "--------------------------------------------------------------"
echo "  People replied to ......... "
"$PY" bot.py --stats 2>/dev/null | sed 's/^/  /'
echo "=============================================================="
echo "  Change answers any time:   bash install-termux.sh"
echo "  Watch live activity:       bash watch.sh"
